module templ-example

go 1.26.4

require github.com/a-h/templ v0.3.1100
